(function() {

  return {

    // Here we define events such as a user clicking on something
    events: {

      // The app is active, so call requestBookmarks (L#65)
      'app.activated': 'renderWoopra'
    },

    // Below this point, you're free to define your own functions used by the app
	
	renderWoopra: function() {
		this.switchTo('profile');

        Widget.require('https://static.woopra.com/js/widgets/embed/woopra.embed.client.min.js?');
        Widget.require('https://static.woopra.com/js/widgets/embed/woopra.embed.client.min.js?');
		var _wac = _wac || {};
		_wac.remote = location.protocol + "//www.woopra.com/widgets/embed";
		_wac.selector = 'woopra-profile';
		_wac.data = {
			website: 'woopra.com',
			id: 'travis@norwall.com',
			theme: 'salesforce',
			type: 'profile'
		};
        window._wac = _wac;
	}
  };

}());
